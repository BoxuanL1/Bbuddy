"""Blackboard Lecture Companion public package."""

__version__ = "0.2.0"
